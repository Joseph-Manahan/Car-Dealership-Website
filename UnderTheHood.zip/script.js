function submitForm() {
  let form = document.getElementById("loginForm");
  let failure = "";
  let breakline = "";
  let userElement = form.elements[0];
  let passwordElement = form.elements[1];
  let max = 20;
  let min = 5;
  if (!userElement.validity.valid) {
    failure += "Invaild username needs at least " + min + " and no more than " + max + " characters";
    breakline = "\n\n";
  }
  if (!passwordElement.validity.valid) {
    failure += breakline + "Invaild password needs at least " + min + " and no more than " + max + " characters";
    breakline = "\n\n";
  }
  if (failure.length != 0) {
    alert(failure);
    return;
  }
  window.location.replace("youloggedin.html");
}

function registrationForm() {
  let failure = "";
  let breakline = "";
  let form = document.getElementById("registrationForm");
  let fNameElement = form.elements[0];
  let lNameElement = form.elements[1];
  let email = form.elements[2];
  let phoneNum = form.elements[3];
  let user = form.elements[4];
  let passwordElement = form.elements[5];
  let min = 5;
  let max = 20;
  if (!fNameElement.validity.valid) {
    failure += "Enter first Name."
    breakline = "\n\n";
  }
  if (!lNameElement.validity.valid) {
    failure += breakline + "Enter last Name."
    breakline = "\n\n";
  }
  if (!email.validity.valid) {
    failure += breakline + "Invalid email. "
    breakline = "\n\n";
  }
  if (!phoneNum.validity.valid) {
    failure += breakline + "Invalid phone number."
    breakline = "\n\n";
  }
  if (!user.validity.valid) {
    failure += breakline + "Invaild username needs at least " + min + " and no more than " + max + " characters";
    breakline = "\n\n";
  }
  if (!passwordElement.validity.valid) {
    failure += breakline + "Invaild password needs at least " + min + " and no more than " + max + " characters";
    breakline = "\n\n";
  }
  if (failure.length != 0) {
    alert(failure);
    return;
  }
  window.location.replace("youloggedin.html");

}

function ChangeLoginInfo() {
  window.location.replace("forgotLogin.html");
}
function sendEmail() {
  let form = document.getElementById("reenterInfo");
  let email = form.elements[0];
  if (!email.validity.valid) {
    alert("Please enter valid email");
    return;
  }
  
  window.location.replace("sentEmail.html");
}
function goBack(){
  window.location.replace("login.html");
}

function performSearch() {
  const searchInput = document.getElementById("searchInput");
  const searchTerm = searchInput.value.trim();
}