document.addEventListener("DOMContentLoaded", function () {
  const slideshowContainer = document.createElement("div");
  slideshowContainer.classList.add("slideshow-container");

  const carImages = ["chevy.jpg", "ford.jpg", "honda.jpg", "tesla.jpg", "toyota.jpg", "23-Nissan-Altima.png"];

  carImages.forEach((imageName, index) => {
    const slide = document.createElement("div");
    slide.classList.add("mySlides");
    if (index === 0) {
      slide.style.display = "block";
    }

    const img = document.createElement("img");
    img.src = "Car Photos/" + imageName; // Updated path
    img.style.width = "100%";

    slide.appendChild(img);
    slideshowContainer.appendChild(slide);
  });

  // Append the slideshow container before the search bar
  const searchContainer = document.querySelector('.bottom-search');
  document.body.insertBefore(slideshowContainer, searchContainer);

  let slideIndex = 0;

  function showSlides() {
    const slides = document.querySelectorAll(".mySlides");
    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
      slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 2000); // Change slide every 2 seconds
  }

  showSlides();
});
